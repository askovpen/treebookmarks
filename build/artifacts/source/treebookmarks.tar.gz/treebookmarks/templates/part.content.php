<p>Welcome <?php p($_['user']) ?></p>


<div id="browser"></div>

